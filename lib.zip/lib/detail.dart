import 'package:flutter/material.dart';

class Detail extends StatefulWidget {
  Detail({Key key}) : super(key: key);

  @override
  DetailState createState() => new DetailState();
}

class DetailState extends State<Detail> {
  @override
  void initState() {
    super.initState();
    print('intro detail');
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          // leading: new Icon(Icons.arrow_back),
          title: Text('detail'),
        ),
        // backgroundColor: Colors.yellow,
        body: new Center(
          child: Text('detail page'),
        ));
  }
}
