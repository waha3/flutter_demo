import 'package:flutter/material.dart';

import 'statelesswidget.dart';
// import 'statefulwidget.dart';
// import 'basewidget.dart';
// import 'home.dart';


// 入口函数
void main() => runApp(new StatelessCom());

