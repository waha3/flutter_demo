import 'package:flutter/material.dart';

// import 'package:dio/dio.dart';
import 'package:english_words/english_words.dart';
import 'dart:convert';
import 'dart:io';
import 'model.dart';
import 'detail.dart';

// Dio dio = new Dio();

class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  HomeState createState() => new HomeState();
}

class HomeState extends State<Home> {
  num page = 0;
  num limit = 20;

  // bool loading = false;
  var list = <WordPair>[];
  var data = [];

  @override
  void initState() {
    super.initState();
    fetchList();
  }

  @override
  void reassemble() {
    super.reassemble();
    fetchList();
  }

  void fetchList() async {
    var http = new HttpClient();
    var uri = new Uri.https('cnodejs.org', '/api/v1/topics',
        {'limit': limit.toString(), 'page': page.toString()});
    var request = await http.getUrl(uri);
    var response = await request.close();
    var body = await response.transform(utf8.decoder).join();
    Map json = jsonDecode(body);
    Topics topics = new Topics.fromJson(json);

    setState(() {
      data.addAll(topics.data);
    });
  }

  Widget buildListView() {
    list.addAll(generateWordPairs().take(10));
    return ListView.separated(
      itemCount: data.length,
      itemBuilder: (context, i) {
        if (i == data.length - 1 && !(data.isEmpty)) {
          page += 1;
          fetchList();
          return Container(
              padding: EdgeInsets.all(2),
              alignment: Alignment.center,
              child: new SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(),
              ));
        }

        if (!(data.isEmpty)) {
          return ListTile(
              title: new Text(data[i]['title'].toString()),
              onTap: () {
                Navigator.push(context,
                    new MaterialPageRoute(builder: (context) {
                  return new Detail();
                }));
              });
        }
      },
      separatorBuilder: (context, i) => new Divider(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
        routes: <String, WidgetBuilder>{'/detail': (context) => Detail()},
        title: 'demo',
        theme: new ThemeData(primaryColor: Colors.green),
        home: new Scaffold(
          appBar: new AppBar(
            title: new Text('flutter'),
          ),
          body: buildListView(),
          drawer: new Drawer(
            child: new Text('1111'),
            elevation: 20,
          ),
        ));
  }
}
