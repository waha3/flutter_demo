class Topics {
  final bool success;
  final List data;

  Topics(this.success, this.data);

  Topics.fromJson(Map<String, dynamic> json)
      : success = json['success'],
        data = json['data'];
}

class Topic {
  final String id;
  final String authorId;
  final String tab;
  final String content;
  final String title;

  Topic({this.id, this.authorId, this.tab, this.content, this.title});

  // Topic.fromJson(Map<String, dynamic> data)
  factory Topic.fromJson(Map<String, dynamic> data) {
    return new Topic(
        id: data['id'],
        authorId: data['id'],
        tab: data['tab'],
        content: data['content'],
        title: data['title']);
  }
}
